#pragma once
// MESSAGE FAULT_DISPLAY PACKING

#define MAVLINK_MSG_ID_FAULT_DISPLAY 196

MAVPACKED(
typedef struct __mavlink_fault_display_t {
 float sensor_display[10]; /*<  sensor value*/
 float show[4]; /*<  unused*/
 uint16_t pwm_display[8]; /*<  pwm value*/
}) mavlink_fault_display_t;

#define MAVLINK_MSG_ID_FAULT_DISPLAY_LEN 72
#define MAVLINK_MSG_ID_FAULT_DISPLAY_MIN_LEN 72
#define MAVLINK_MSG_ID_196_LEN 72
#define MAVLINK_MSG_ID_196_MIN_LEN 72

#define MAVLINK_MSG_ID_FAULT_DISPLAY_CRC 108
#define MAVLINK_MSG_ID_196_CRC 108

#define MAVLINK_MSG_FAULT_DISPLAY_FIELD_SENSOR_DISPLAY_LEN 10
#define MAVLINK_MSG_FAULT_DISPLAY_FIELD_SHOW_LEN 4
#define MAVLINK_MSG_FAULT_DISPLAY_FIELD_PWM_DISPLAY_LEN 8

#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_FAULT_DISPLAY { \
    196, \
    "FAULT_DISPLAY", \
    3, \
    {  { "pwm_display", NULL, MAVLINK_TYPE_UINT16_T, 8, 56, offsetof(mavlink_fault_display_t, pwm_display) }, \
         { "sensor_display", NULL, MAVLINK_TYPE_FLOAT, 10, 0, offsetof(mavlink_fault_display_t, sensor_display) }, \
         { "show", NULL, MAVLINK_TYPE_FLOAT, 4, 40, offsetof(mavlink_fault_display_t, show) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_FAULT_DISPLAY { \
    "FAULT_DISPLAY", \
    3, \
    {  { "pwm_display", NULL, MAVLINK_TYPE_UINT16_T, 8, 56, offsetof(mavlink_fault_display_t, pwm_display) }, \
         { "sensor_display", NULL, MAVLINK_TYPE_FLOAT, 10, 0, offsetof(mavlink_fault_display_t, sensor_display) }, \
         { "show", NULL, MAVLINK_TYPE_FLOAT, 4, 40, offsetof(mavlink_fault_display_t, show) }, \
         } \
}
#endif

/**
 * @brief Pack a fault_display message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param pwm_display  pwm value
 * @param sensor_display  sensor value
 * @param show  unused
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_fault_display_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               const uint16_t *pwm_display, const float *sensor_display, const float *show)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_FAULT_DISPLAY_LEN];

    _mav_put_float_array(buf, 0, sensor_display, 10);
    _mav_put_float_array(buf, 40, show, 4);
    _mav_put_uint16_t_array(buf, 56, pwm_display, 8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_FAULT_DISPLAY_LEN);
#else
    mavlink_fault_display_t packet;

    mav_array_memcpy(packet.sensor_display, sensor_display, sizeof(float)*10);
    mav_array_memcpy(packet.show, show, sizeof(float)*4);
    mav_array_memcpy(packet.pwm_display, pwm_display, sizeof(uint16_t)*8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_FAULT_DISPLAY_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_FAULT_DISPLAY;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_FAULT_DISPLAY_MIN_LEN, MAVLINK_MSG_ID_FAULT_DISPLAY_LEN, MAVLINK_MSG_ID_FAULT_DISPLAY_CRC);
}

/**
 * @brief Pack a fault_display message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param pwm_display  pwm value
 * @param sensor_display  sensor value
 * @param show  unused
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_fault_display_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   const uint16_t *pwm_display,const float *sensor_display,const float *show)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_FAULT_DISPLAY_LEN];

    _mav_put_float_array(buf, 0, sensor_display, 10);
    _mav_put_float_array(buf, 40, show, 4);
    _mav_put_uint16_t_array(buf, 56, pwm_display, 8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_FAULT_DISPLAY_LEN);
#else
    mavlink_fault_display_t packet;

    mav_array_memcpy(packet.sensor_display, sensor_display, sizeof(float)*10);
    mav_array_memcpy(packet.show, show, sizeof(float)*4);
    mav_array_memcpy(packet.pwm_display, pwm_display, sizeof(uint16_t)*8);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_FAULT_DISPLAY_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_FAULT_DISPLAY;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_FAULT_DISPLAY_MIN_LEN, MAVLINK_MSG_ID_FAULT_DISPLAY_LEN, MAVLINK_MSG_ID_FAULT_DISPLAY_CRC);
}

/**
 * @brief Encode a fault_display struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param fault_display C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_fault_display_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_fault_display_t* fault_display)
{
    return mavlink_msg_fault_display_pack(system_id, component_id, msg, fault_display->pwm_display, fault_display->sensor_display, fault_display->show);
}

/**
 * @brief Encode a fault_display struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param fault_display C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_fault_display_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_fault_display_t* fault_display)
{
    return mavlink_msg_fault_display_pack_chan(system_id, component_id, chan, msg, fault_display->pwm_display, fault_display->sensor_display, fault_display->show);
}

/**
 * @brief Send a fault_display message
 * @param chan MAVLink channel to send the message
 *
 * @param pwm_display  pwm value
 * @param sensor_display  sensor value
 * @param show  unused
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_fault_display_send(mavlink_channel_t chan, const uint16_t *pwm_display, const float *sensor_display, const float *show)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_FAULT_DISPLAY_LEN];

    _mav_put_float_array(buf, 0, sensor_display, 10);
    _mav_put_float_array(buf, 40, show, 4);
    _mav_put_uint16_t_array(buf, 56, pwm_display, 8);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FAULT_DISPLAY, buf, MAVLINK_MSG_ID_FAULT_DISPLAY_MIN_LEN, MAVLINK_MSG_ID_FAULT_DISPLAY_LEN, MAVLINK_MSG_ID_FAULT_DISPLAY_CRC);
#else
    mavlink_fault_display_t packet;

    mav_array_memcpy(packet.sensor_display, sensor_display, sizeof(float)*10);
    mav_array_memcpy(packet.show, show, sizeof(float)*4);
    mav_array_memcpy(packet.pwm_display, pwm_display, sizeof(uint16_t)*8);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FAULT_DISPLAY, (const char *)&packet, MAVLINK_MSG_ID_FAULT_DISPLAY_MIN_LEN, MAVLINK_MSG_ID_FAULT_DISPLAY_LEN, MAVLINK_MSG_ID_FAULT_DISPLAY_CRC);
#endif
}

/**
 * @brief Send a fault_display message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_fault_display_send_struct(mavlink_channel_t chan, const mavlink_fault_display_t* fault_display)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_fault_display_send(chan, fault_display->pwm_display, fault_display->sensor_display, fault_display->show);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FAULT_DISPLAY, (const char *)fault_display, MAVLINK_MSG_ID_FAULT_DISPLAY_MIN_LEN, MAVLINK_MSG_ID_FAULT_DISPLAY_LEN, MAVLINK_MSG_ID_FAULT_DISPLAY_CRC);
#endif
}

#if MAVLINK_MSG_ID_FAULT_DISPLAY_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_fault_display_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  const uint16_t *pwm_display, const float *sensor_display, const float *show)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;

    _mav_put_float_array(buf, 0, sensor_display, 10);
    _mav_put_float_array(buf, 40, show, 4);
    _mav_put_uint16_t_array(buf, 56, pwm_display, 8);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FAULT_DISPLAY, buf, MAVLINK_MSG_ID_FAULT_DISPLAY_MIN_LEN, MAVLINK_MSG_ID_FAULT_DISPLAY_LEN, MAVLINK_MSG_ID_FAULT_DISPLAY_CRC);
#else
    mavlink_fault_display_t *packet = (mavlink_fault_display_t *)msgbuf;

    mav_array_memcpy(packet->sensor_display, sensor_display, sizeof(float)*10);
    mav_array_memcpy(packet->show, show, sizeof(float)*4);
    mav_array_memcpy(packet->pwm_display, pwm_display, sizeof(uint16_t)*8);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FAULT_DISPLAY, (const char *)packet, MAVLINK_MSG_ID_FAULT_DISPLAY_MIN_LEN, MAVLINK_MSG_ID_FAULT_DISPLAY_LEN, MAVLINK_MSG_ID_FAULT_DISPLAY_CRC);
#endif
}
#endif

#endif

// MESSAGE FAULT_DISPLAY UNPACKING


/**
 * @brief Get field pwm_display from fault_display message
 *
 * @return  pwm value
 */
static inline uint16_t mavlink_msg_fault_display_get_pwm_display(const mavlink_message_t* msg, uint16_t *pwm_display)
{
    return _MAV_RETURN_uint16_t_array(msg, pwm_display, 8,  56);
}

/**
 * @brief Get field sensor_display from fault_display message
 *
 * @return  sensor value
 */
static inline uint16_t mavlink_msg_fault_display_get_sensor_display(const mavlink_message_t* msg, float *sensor_display)
{
    return _MAV_RETURN_float_array(msg, sensor_display, 10,  0);
}

/**
 * @brief Get field show from fault_display message
 *
 * @return  unused
 */
static inline uint16_t mavlink_msg_fault_display_get_show(const mavlink_message_t* msg, float *show)
{
    return _MAV_RETURN_float_array(msg, show, 4,  40);
}

/**
 * @brief Decode a fault_display message into a struct
 *
 * @param msg The message to decode
 * @param fault_display C-struct to decode the message contents into
 */
static inline void mavlink_msg_fault_display_decode(const mavlink_message_t* msg, mavlink_fault_display_t* fault_display)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_fault_display_get_sensor_display(msg, fault_display->sensor_display);
    mavlink_msg_fault_display_get_show(msg, fault_display->show);
    mavlink_msg_fault_display_get_pwm_display(msg, fault_display->pwm_display);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_FAULT_DISPLAY_LEN? msg->len : MAVLINK_MSG_ID_FAULT_DISPLAY_LEN;
        memset(fault_display, 0, MAVLINK_MSG_ID_FAULT_DISPLAY_LEN);
    memcpy(fault_display, _MAV_PAYLOAD(msg), len);
#endif
}
