#pragma once
// MESSAGE TRACK_POSITION PACKING

#define MAVLINK_MSG_ID_TRACK_POSITION 188

MAVPACKED(
typedef struct __mavlink_track_position_t {
 float relat_pos[6]; /*<  relat pos*/
 float track_pos[3]; /*<  vision track pos*/
 float land_pos[3]; /*<  vision land pos*/
}) mavlink_track_position_t;

#define MAVLINK_MSG_ID_TRACK_POSITION_LEN 48
#define MAVLINK_MSG_ID_TRACK_POSITION_MIN_LEN 48
#define MAVLINK_MSG_ID_188_LEN 48
#define MAVLINK_MSG_ID_188_MIN_LEN 48

#define MAVLINK_MSG_ID_TRACK_POSITION_CRC 116
#define MAVLINK_MSG_ID_188_CRC 116

#define MAVLINK_MSG_TRACK_POSITION_FIELD_RELAT_POS_LEN 6
#define MAVLINK_MSG_TRACK_POSITION_FIELD_TRACK_POS_LEN 3
#define MAVLINK_MSG_TRACK_POSITION_FIELD_LAND_POS_LEN 3

#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_TRACK_POSITION { \
    188, \
    "TRACK_POSITION", \
    3, \
    {  { "relat_pos", NULL, MAVLINK_TYPE_FLOAT, 6, 0, offsetof(mavlink_track_position_t, relat_pos) }, \
         { "track_pos", NULL, MAVLINK_TYPE_FLOAT, 3, 24, offsetof(mavlink_track_position_t, track_pos) }, \
         { "land_pos", NULL, MAVLINK_TYPE_FLOAT, 3, 36, offsetof(mavlink_track_position_t, land_pos) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_TRACK_POSITION { \
    "TRACK_POSITION", \
    3, \
    {  { "relat_pos", NULL, MAVLINK_TYPE_FLOAT, 6, 0, offsetof(mavlink_track_position_t, relat_pos) }, \
         { "track_pos", NULL, MAVLINK_TYPE_FLOAT, 3, 24, offsetof(mavlink_track_position_t, track_pos) }, \
         { "land_pos", NULL, MAVLINK_TYPE_FLOAT, 3, 36, offsetof(mavlink_track_position_t, land_pos) }, \
         } \
}
#endif

/**
 * @brief Pack a track_position message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param relat_pos  relat pos
 * @param track_pos  vision track pos
 * @param land_pos  vision land pos
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_track_position_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               const float *relat_pos, const float *track_pos, const float *land_pos)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_TRACK_POSITION_LEN];

    _mav_put_float_array(buf, 0, relat_pos, 6);
    _mav_put_float_array(buf, 24, track_pos, 3);
    _mav_put_float_array(buf, 36, land_pos, 3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_TRACK_POSITION_LEN);
#else
    mavlink_track_position_t packet;

    mav_array_memcpy(packet.relat_pos, relat_pos, sizeof(float)*6);
    mav_array_memcpy(packet.track_pos, track_pos, sizeof(float)*3);
    mav_array_memcpy(packet.land_pos, land_pos, sizeof(float)*3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_TRACK_POSITION_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_TRACK_POSITION;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_TRACK_POSITION_MIN_LEN, MAVLINK_MSG_ID_TRACK_POSITION_LEN, MAVLINK_MSG_ID_TRACK_POSITION_CRC);
}

/**
 * @brief Pack a track_position message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param relat_pos  relat pos
 * @param track_pos  vision track pos
 * @param land_pos  vision land pos
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_track_position_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   const float *relat_pos,const float *track_pos,const float *land_pos)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_TRACK_POSITION_LEN];

    _mav_put_float_array(buf, 0, relat_pos, 6);
    _mav_put_float_array(buf, 24, track_pos, 3);
    _mav_put_float_array(buf, 36, land_pos, 3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_TRACK_POSITION_LEN);
#else
    mavlink_track_position_t packet;

    mav_array_memcpy(packet.relat_pos, relat_pos, sizeof(float)*6);
    mav_array_memcpy(packet.track_pos, track_pos, sizeof(float)*3);
    mav_array_memcpy(packet.land_pos, land_pos, sizeof(float)*3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_TRACK_POSITION_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_TRACK_POSITION;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_TRACK_POSITION_MIN_LEN, MAVLINK_MSG_ID_TRACK_POSITION_LEN, MAVLINK_MSG_ID_TRACK_POSITION_CRC);
}

/**
 * @brief Encode a track_position struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param track_position C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_track_position_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_track_position_t* track_position)
{
    return mavlink_msg_track_position_pack(system_id, component_id, msg, track_position->relat_pos, track_position->track_pos, track_position->land_pos);
}

/**
 * @brief Encode a track_position struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param track_position C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_track_position_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_track_position_t* track_position)
{
    return mavlink_msg_track_position_pack_chan(system_id, component_id, chan, msg, track_position->relat_pos, track_position->track_pos, track_position->land_pos);
}

/**
 * @brief Send a track_position message
 * @param chan MAVLink channel to send the message
 *
 * @param relat_pos  relat pos
 * @param track_pos  vision track pos
 * @param land_pos  vision land pos
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_track_position_send(mavlink_channel_t chan, const float *relat_pos, const float *track_pos, const float *land_pos)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_TRACK_POSITION_LEN];

    _mav_put_float_array(buf, 0, relat_pos, 6);
    _mav_put_float_array(buf, 24, track_pos, 3);
    _mav_put_float_array(buf, 36, land_pos, 3);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TRACK_POSITION, buf, MAVLINK_MSG_ID_TRACK_POSITION_MIN_LEN, MAVLINK_MSG_ID_TRACK_POSITION_LEN, MAVLINK_MSG_ID_TRACK_POSITION_CRC);
#else
    mavlink_track_position_t packet;

    mav_array_memcpy(packet.relat_pos, relat_pos, sizeof(float)*6);
    mav_array_memcpy(packet.track_pos, track_pos, sizeof(float)*3);
    mav_array_memcpy(packet.land_pos, land_pos, sizeof(float)*3);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TRACK_POSITION, (const char *)&packet, MAVLINK_MSG_ID_TRACK_POSITION_MIN_LEN, MAVLINK_MSG_ID_TRACK_POSITION_LEN, MAVLINK_MSG_ID_TRACK_POSITION_CRC);
#endif
}

/**
 * @brief Send a track_position message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_track_position_send_struct(mavlink_channel_t chan, const mavlink_track_position_t* track_position)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_track_position_send(chan, track_position->relat_pos, track_position->track_pos, track_position->land_pos);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TRACK_POSITION, (const char *)track_position, MAVLINK_MSG_ID_TRACK_POSITION_MIN_LEN, MAVLINK_MSG_ID_TRACK_POSITION_LEN, MAVLINK_MSG_ID_TRACK_POSITION_CRC);
#endif
}

#if MAVLINK_MSG_ID_TRACK_POSITION_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_track_position_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  const float *relat_pos, const float *track_pos, const float *land_pos)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;

    _mav_put_float_array(buf, 0, relat_pos, 6);
    _mav_put_float_array(buf, 24, track_pos, 3);
    _mav_put_float_array(buf, 36, land_pos, 3);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TRACK_POSITION, buf, MAVLINK_MSG_ID_TRACK_POSITION_MIN_LEN, MAVLINK_MSG_ID_TRACK_POSITION_LEN, MAVLINK_MSG_ID_TRACK_POSITION_CRC);
#else
    mavlink_track_position_t *packet = (mavlink_track_position_t *)msgbuf;

    mav_array_memcpy(packet->relat_pos, relat_pos, sizeof(float)*6);
    mav_array_memcpy(packet->track_pos, track_pos, sizeof(float)*3);
    mav_array_memcpy(packet->land_pos, land_pos, sizeof(float)*3);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_TRACK_POSITION, (const char *)packet, MAVLINK_MSG_ID_TRACK_POSITION_MIN_LEN, MAVLINK_MSG_ID_TRACK_POSITION_LEN, MAVLINK_MSG_ID_TRACK_POSITION_CRC);
#endif
}
#endif

#endif

// MESSAGE TRACK_POSITION UNPACKING


/**
 * @brief Get field relat_pos from track_position message
 *
 * @return  relat pos
 */
static inline uint16_t mavlink_msg_track_position_get_relat_pos(const mavlink_message_t* msg, float *relat_pos)
{
    return _MAV_RETURN_float_array(msg, relat_pos, 6,  0);
}

/**
 * @brief Get field track_pos from track_position message
 *
 * @return  vision track pos
 */
static inline uint16_t mavlink_msg_track_position_get_track_pos(const mavlink_message_t* msg, float *track_pos)
{
    return _MAV_RETURN_float_array(msg, track_pos, 3,  24);
}

/**
 * @brief Get field land_pos from track_position message
 *
 * @return  vision land pos
 */
static inline uint16_t mavlink_msg_track_position_get_land_pos(const mavlink_message_t* msg, float *land_pos)
{
    return _MAV_RETURN_float_array(msg, land_pos, 3,  36);
}

/**
 * @brief Decode a track_position message into a struct
 *
 * @param msg The message to decode
 * @param track_position C-struct to decode the message contents into
 */
static inline void mavlink_msg_track_position_decode(const mavlink_message_t* msg, mavlink_track_position_t* track_position)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_track_position_get_relat_pos(msg, track_position->relat_pos);
    mavlink_msg_track_position_get_track_pos(msg, track_position->track_pos);
    mavlink_msg_track_position_get_land_pos(msg, track_position->land_pos);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_TRACK_POSITION_LEN? msg->len : MAVLINK_MSG_ID_TRACK_POSITION_LEN;
        memset(track_position, 0, MAVLINK_MSG_ID_TRACK_POSITION_LEN);
    memcpy(track_position, _MAV_PAYLOAD(msg), len);
#endif
}
