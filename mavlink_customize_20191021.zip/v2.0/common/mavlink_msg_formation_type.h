#pragma once
// MESSAGE FORMATION_TYPE PACKING

#define MAVLINK_MSG_ID_FORMATION_TYPE 187

MAVPACKED(
typedef struct __mavlink_formation_type_t {
 uint8_t target_id; /*<  copter id*/
 uint8_t formation_type; /*<  formation type*/
 uint8_t start_end; /*<  start end*/
 uint8_t unused; /*<  unused*/
}) mavlink_formation_type_t;

#define MAVLINK_MSG_ID_FORMATION_TYPE_LEN 4
#define MAVLINK_MSG_ID_FORMATION_TYPE_MIN_LEN 4
#define MAVLINK_MSG_ID_187_LEN 4
#define MAVLINK_MSG_ID_187_MIN_LEN 4

#define MAVLINK_MSG_ID_FORMATION_TYPE_CRC 125
#define MAVLINK_MSG_ID_187_CRC 125



#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_FORMATION_TYPE { \
    187, \
    "FORMATION_TYPE", \
    4, \
    {  { "target_id", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_formation_type_t, target_id) }, \
         { "formation_type", NULL, MAVLINK_TYPE_UINT8_T, 0, 1, offsetof(mavlink_formation_type_t, formation_type) }, \
         { "start_end", NULL, MAVLINK_TYPE_UINT8_T, 0, 2, offsetof(mavlink_formation_type_t, start_end) }, \
         { "unused", NULL, MAVLINK_TYPE_UINT8_T, 0, 3, offsetof(mavlink_formation_type_t, unused) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_FORMATION_TYPE { \
    "FORMATION_TYPE", \
    4, \
    {  { "target_id", NULL, MAVLINK_TYPE_UINT8_T, 0, 0, offsetof(mavlink_formation_type_t, target_id) }, \
         { "formation_type", NULL, MAVLINK_TYPE_UINT8_T, 0, 1, offsetof(mavlink_formation_type_t, formation_type) }, \
         { "start_end", NULL, MAVLINK_TYPE_UINT8_T, 0, 2, offsetof(mavlink_formation_type_t, start_end) }, \
         { "unused", NULL, MAVLINK_TYPE_UINT8_T, 0, 3, offsetof(mavlink_formation_type_t, unused) }, \
         } \
}
#endif

/**
 * @brief Pack a formation_type message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param target_id  copter id
 * @param formation_type  formation type
 * @param start_end  start end
 * @param unused  unused
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_formation_type_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint8_t target_id, uint8_t formation_type, uint8_t start_end, uint8_t unused)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_FORMATION_TYPE_LEN];
    _mav_put_uint8_t(buf, 0, target_id);
    _mav_put_uint8_t(buf, 1, formation_type);
    _mav_put_uint8_t(buf, 2, start_end);
    _mav_put_uint8_t(buf, 3, unused);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_FORMATION_TYPE_LEN);
#else
    mavlink_formation_type_t packet;
    packet.target_id = target_id;
    packet.formation_type = formation_type;
    packet.start_end = start_end;
    packet.unused = unused;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_FORMATION_TYPE_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_FORMATION_TYPE;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_FORMATION_TYPE_MIN_LEN, MAVLINK_MSG_ID_FORMATION_TYPE_LEN, MAVLINK_MSG_ID_FORMATION_TYPE_CRC);
}

/**
 * @brief Pack a formation_type message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param target_id  copter id
 * @param formation_type  formation type
 * @param start_end  start end
 * @param unused  unused
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_formation_type_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint8_t target_id,uint8_t formation_type,uint8_t start_end,uint8_t unused)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_FORMATION_TYPE_LEN];
    _mav_put_uint8_t(buf, 0, target_id);
    _mav_put_uint8_t(buf, 1, formation_type);
    _mav_put_uint8_t(buf, 2, start_end);
    _mav_put_uint8_t(buf, 3, unused);

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_FORMATION_TYPE_LEN);
#else
    mavlink_formation_type_t packet;
    packet.target_id = target_id;
    packet.formation_type = formation_type;
    packet.start_end = start_end;
    packet.unused = unused;

        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_FORMATION_TYPE_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_FORMATION_TYPE;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_FORMATION_TYPE_MIN_LEN, MAVLINK_MSG_ID_FORMATION_TYPE_LEN, MAVLINK_MSG_ID_FORMATION_TYPE_CRC);
}

/**
 * @brief Encode a formation_type struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param formation_type C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_formation_type_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_formation_type_t* formation_type)
{
    return mavlink_msg_formation_type_pack(system_id, component_id, msg, formation_type->target_id, formation_type->formation_type, formation_type->start_end, formation_type->unused);
}

/**
 * @brief Encode a formation_type struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param formation_type C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_formation_type_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_formation_type_t* formation_type)
{
    return mavlink_msg_formation_type_pack_chan(system_id, component_id, chan, msg, formation_type->target_id, formation_type->formation_type, formation_type->start_end, formation_type->unused);
}

/**
 * @brief Send a formation_type message
 * @param chan MAVLink channel to send the message
 *
 * @param target_id  copter id
 * @param formation_type  formation type
 * @param start_end  start end
 * @param unused  unused
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_formation_type_send(mavlink_channel_t chan, uint8_t target_id, uint8_t formation_type, uint8_t start_end, uint8_t unused)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_FORMATION_TYPE_LEN];
    _mav_put_uint8_t(buf, 0, target_id);
    _mav_put_uint8_t(buf, 1, formation_type);
    _mav_put_uint8_t(buf, 2, start_end);
    _mav_put_uint8_t(buf, 3, unused);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FORMATION_TYPE, buf, MAVLINK_MSG_ID_FORMATION_TYPE_MIN_LEN, MAVLINK_MSG_ID_FORMATION_TYPE_LEN, MAVLINK_MSG_ID_FORMATION_TYPE_CRC);
#else
    mavlink_formation_type_t packet;
    packet.target_id = target_id;
    packet.formation_type = formation_type;
    packet.start_end = start_end;
    packet.unused = unused;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FORMATION_TYPE, (const char *)&packet, MAVLINK_MSG_ID_FORMATION_TYPE_MIN_LEN, MAVLINK_MSG_ID_FORMATION_TYPE_LEN, MAVLINK_MSG_ID_FORMATION_TYPE_CRC);
#endif
}

/**
 * @brief Send a formation_type message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_formation_type_send_struct(mavlink_channel_t chan, const mavlink_formation_type_t* formation_type)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_formation_type_send(chan, formation_type->target_id, formation_type->formation_type, formation_type->start_end, formation_type->unused);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FORMATION_TYPE, (const char *)formation_type, MAVLINK_MSG_ID_FORMATION_TYPE_MIN_LEN, MAVLINK_MSG_ID_FORMATION_TYPE_LEN, MAVLINK_MSG_ID_FORMATION_TYPE_CRC);
#endif
}

#if MAVLINK_MSG_ID_FORMATION_TYPE_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_formation_type_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint8_t target_id, uint8_t formation_type, uint8_t start_end, uint8_t unused)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint8_t(buf, 0, target_id);
    _mav_put_uint8_t(buf, 1, formation_type);
    _mav_put_uint8_t(buf, 2, start_end);
    _mav_put_uint8_t(buf, 3, unused);

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FORMATION_TYPE, buf, MAVLINK_MSG_ID_FORMATION_TYPE_MIN_LEN, MAVLINK_MSG_ID_FORMATION_TYPE_LEN, MAVLINK_MSG_ID_FORMATION_TYPE_CRC);
#else
    mavlink_formation_type_t *packet = (mavlink_formation_type_t *)msgbuf;
    packet->target_id = target_id;
    packet->formation_type = formation_type;
    packet->start_end = start_end;
    packet->unused = unused;

    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FORMATION_TYPE, (const char *)packet, MAVLINK_MSG_ID_FORMATION_TYPE_MIN_LEN, MAVLINK_MSG_ID_FORMATION_TYPE_LEN, MAVLINK_MSG_ID_FORMATION_TYPE_CRC);
#endif
}
#endif

#endif

// MESSAGE FORMATION_TYPE UNPACKING


/**
 * @brief Get field target_id from formation_type message
 *
 * @return  copter id
 */
static inline uint8_t mavlink_msg_formation_type_get_target_id(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  0);
}

/**
 * @brief Get field formation_type from formation_type message
 *
 * @return  formation type
 */
static inline uint8_t mavlink_msg_formation_type_get_formation_type(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  1);
}

/**
 * @brief Get field start_end from formation_type message
 *
 * @return  start end
 */
static inline uint8_t mavlink_msg_formation_type_get_start_end(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  2);
}

/**
 * @brief Get field unused from formation_type message
 *
 * @return  unused
 */
static inline uint8_t mavlink_msg_formation_type_get_unused(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  3);
}

/**
 * @brief Decode a formation_type message into a struct
 *
 * @param msg The message to decode
 * @param formation_type C-struct to decode the message contents into
 */
static inline void mavlink_msg_formation_type_decode(const mavlink_message_t* msg, mavlink_formation_type_t* formation_type)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    formation_type->target_id = mavlink_msg_formation_type_get_target_id(msg);
    formation_type->formation_type = mavlink_msg_formation_type_get_formation_type(msg);
    formation_type->start_end = mavlink_msg_formation_type_get_start_end(msg);
    formation_type->unused = mavlink_msg_formation_type_get_unused(msg);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_FORMATION_TYPE_LEN? msg->len : MAVLINK_MSG_ID_FORMATION_TYPE_LEN;
        memset(formation_type, 0, MAVLINK_MSG_ID_FORMATION_TYPE_LEN);
    memcpy(formation_type, _MAV_PAYLOAD(msg), len);
#endif
}
