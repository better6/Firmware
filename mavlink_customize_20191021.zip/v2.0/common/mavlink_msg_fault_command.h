#pragma once
// MESSAGE FAULT_COMMAND PACKING

#define MAVLINK_MSG_ID_FAULT_COMMAND 189

MAVPACKED(
typedef struct __mavlink_fault_command_t {
 float motor_ratio[6]; /*<  motor fault ratio*/
 float motor_time[6]; /*<  motor fault time*/
 float sensor_ratio[10]; /*<  sensor fault ratio*/
 float sensor_time[10]; /*<  sensor fault time*/
 uint8_t instruct[4]; /*<  unused*/
}) mavlink_fault_command_t;

#define MAVLINK_MSG_ID_FAULT_COMMAND_LEN 132
#define MAVLINK_MSG_ID_FAULT_COMMAND_MIN_LEN 132
#define MAVLINK_MSG_ID_189_LEN 132
#define MAVLINK_MSG_ID_189_MIN_LEN 132

#define MAVLINK_MSG_ID_FAULT_COMMAND_CRC 239
#define MAVLINK_MSG_ID_189_CRC 239

#define MAVLINK_MSG_FAULT_COMMAND_FIELD_MOTOR_RATIO_LEN 6
#define MAVLINK_MSG_FAULT_COMMAND_FIELD_MOTOR_TIME_LEN 6
#define MAVLINK_MSG_FAULT_COMMAND_FIELD_SENSOR_RATIO_LEN 10
#define MAVLINK_MSG_FAULT_COMMAND_FIELD_SENSOR_TIME_LEN 10
#define MAVLINK_MSG_FAULT_COMMAND_FIELD_INSTRUCT_LEN 4

#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_FAULT_COMMAND { \
    189, \
    "FAULT_COMMAND", \
    5, \
    {  { "motor_ratio", NULL, MAVLINK_TYPE_FLOAT, 6, 0, offsetof(mavlink_fault_command_t, motor_ratio) }, \
         { "motor_time", NULL, MAVLINK_TYPE_FLOAT, 6, 24, offsetof(mavlink_fault_command_t, motor_time) }, \
         { "sensor_ratio", NULL, MAVLINK_TYPE_FLOAT, 10, 48, offsetof(mavlink_fault_command_t, sensor_ratio) }, \
         { "sensor_time", NULL, MAVLINK_TYPE_FLOAT, 10, 88, offsetof(mavlink_fault_command_t, sensor_time) }, \
         { "instruct", NULL, MAVLINK_TYPE_UINT8_T, 4, 128, offsetof(mavlink_fault_command_t, instruct) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_FAULT_COMMAND { \
    "FAULT_COMMAND", \
    5, \
    {  { "motor_ratio", NULL, MAVLINK_TYPE_FLOAT, 6, 0, offsetof(mavlink_fault_command_t, motor_ratio) }, \
         { "motor_time", NULL, MAVLINK_TYPE_FLOAT, 6, 24, offsetof(mavlink_fault_command_t, motor_time) }, \
         { "sensor_ratio", NULL, MAVLINK_TYPE_FLOAT, 10, 48, offsetof(mavlink_fault_command_t, sensor_ratio) }, \
         { "sensor_time", NULL, MAVLINK_TYPE_FLOAT, 10, 88, offsetof(mavlink_fault_command_t, sensor_time) }, \
         { "instruct", NULL, MAVLINK_TYPE_UINT8_T, 4, 128, offsetof(mavlink_fault_command_t, instruct) }, \
         } \
}
#endif

/**
 * @brief Pack a fault_command message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param motor_ratio  motor fault ratio
 * @param motor_time  motor fault time
 * @param sensor_ratio  sensor fault ratio
 * @param sensor_time  sensor fault time
 * @param instruct  unused
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_fault_command_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               const float *motor_ratio, const float *motor_time, const float *sensor_ratio, const float *sensor_time, const uint8_t *instruct)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_FAULT_COMMAND_LEN];

    _mav_put_float_array(buf, 0, motor_ratio, 6);
    _mav_put_float_array(buf, 24, motor_time, 6);
    _mav_put_float_array(buf, 48, sensor_ratio, 10);
    _mav_put_float_array(buf, 88, sensor_time, 10);
    _mav_put_uint8_t_array(buf, 128, instruct, 4);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_FAULT_COMMAND_LEN);
#else
    mavlink_fault_command_t packet;

    mav_array_memcpy(packet.motor_ratio, motor_ratio, sizeof(float)*6);
    mav_array_memcpy(packet.motor_time, motor_time, sizeof(float)*6);
    mav_array_memcpy(packet.sensor_ratio, sensor_ratio, sizeof(float)*10);
    mav_array_memcpy(packet.sensor_time, sensor_time, sizeof(float)*10);
    mav_array_memcpy(packet.instruct, instruct, sizeof(uint8_t)*4);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_FAULT_COMMAND_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_FAULT_COMMAND;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_FAULT_COMMAND_MIN_LEN, MAVLINK_MSG_ID_FAULT_COMMAND_LEN, MAVLINK_MSG_ID_FAULT_COMMAND_CRC);
}

/**
 * @brief Pack a fault_command message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param motor_ratio  motor fault ratio
 * @param motor_time  motor fault time
 * @param sensor_ratio  sensor fault ratio
 * @param sensor_time  sensor fault time
 * @param instruct  unused
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_fault_command_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   const float *motor_ratio,const float *motor_time,const float *sensor_ratio,const float *sensor_time,const uint8_t *instruct)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_FAULT_COMMAND_LEN];

    _mav_put_float_array(buf, 0, motor_ratio, 6);
    _mav_put_float_array(buf, 24, motor_time, 6);
    _mav_put_float_array(buf, 48, sensor_ratio, 10);
    _mav_put_float_array(buf, 88, sensor_time, 10);
    _mav_put_uint8_t_array(buf, 128, instruct, 4);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_FAULT_COMMAND_LEN);
#else
    mavlink_fault_command_t packet;

    mav_array_memcpy(packet.motor_ratio, motor_ratio, sizeof(float)*6);
    mav_array_memcpy(packet.motor_time, motor_time, sizeof(float)*6);
    mav_array_memcpy(packet.sensor_ratio, sensor_ratio, sizeof(float)*10);
    mav_array_memcpy(packet.sensor_time, sensor_time, sizeof(float)*10);
    mav_array_memcpy(packet.instruct, instruct, sizeof(uint8_t)*4);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_FAULT_COMMAND_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_FAULT_COMMAND;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_FAULT_COMMAND_MIN_LEN, MAVLINK_MSG_ID_FAULT_COMMAND_LEN, MAVLINK_MSG_ID_FAULT_COMMAND_CRC);
}

/**
 * @brief Encode a fault_command struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param fault_command C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_fault_command_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_fault_command_t* fault_command)
{
    return mavlink_msg_fault_command_pack(system_id, component_id, msg, fault_command->motor_ratio, fault_command->motor_time, fault_command->sensor_ratio, fault_command->sensor_time, fault_command->instruct);
}

/**
 * @brief Encode a fault_command struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param fault_command C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_fault_command_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_fault_command_t* fault_command)
{
    return mavlink_msg_fault_command_pack_chan(system_id, component_id, chan, msg, fault_command->motor_ratio, fault_command->motor_time, fault_command->sensor_ratio, fault_command->sensor_time, fault_command->instruct);
}

/**
 * @brief Send a fault_command message
 * @param chan MAVLink channel to send the message
 *
 * @param motor_ratio  motor fault ratio
 * @param motor_time  motor fault time
 * @param sensor_ratio  sensor fault ratio
 * @param sensor_time  sensor fault time
 * @param instruct  unused
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_fault_command_send(mavlink_channel_t chan, const float *motor_ratio, const float *motor_time, const float *sensor_ratio, const float *sensor_time, const uint8_t *instruct)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_FAULT_COMMAND_LEN];

    _mav_put_float_array(buf, 0, motor_ratio, 6);
    _mav_put_float_array(buf, 24, motor_time, 6);
    _mav_put_float_array(buf, 48, sensor_ratio, 10);
    _mav_put_float_array(buf, 88, sensor_time, 10);
    _mav_put_uint8_t_array(buf, 128, instruct, 4);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FAULT_COMMAND, buf, MAVLINK_MSG_ID_FAULT_COMMAND_MIN_LEN, MAVLINK_MSG_ID_FAULT_COMMAND_LEN, MAVLINK_MSG_ID_FAULT_COMMAND_CRC);
#else
    mavlink_fault_command_t packet;

    mav_array_memcpy(packet.motor_ratio, motor_ratio, sizeof(float)*6);
    mav_array_memcpy(packet.motor_time, motor_time, sizeof(float)*6);
    mav_array_memcpy(packet.sensor_ratio, sensor_ratio, sizeof(float)*10);
    mav_array_memcpy(packet.sensor_time, sensor_time, sizeof(float)*10);
    mav_array_memcpy(packet.instruct, instruct, sizeof(uint8_t)*4);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FAULT_COMMAND, (const char *)&packet, MAVLINK_MSG_ID_FAULT_COMMAND_MIN_LEN, MAVLINK_MSG_ID_FAULT_COMMAND_LEN, MAVLINK_MSG_ID_FAULT_COMMAND_CRC);
#endif
}

/**
 * @brief Send a fault_command message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_fault_command_send_struct(mavlink_channel_t chan, const mavlink_fault_command_t* fault_command)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_fault_command_send(chan, fault_command->motor_ratio, fault_command->motor_time, fault_command->sensor_ratio, fault_command->sensor_time, fault_command->instruct);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FAULT_COMMAND, (const char *)fault_command, MAVLINK_MSG_ID_FAULT_COMMAND_MIN_LEN, MAVLINK_MSG_ID_FAULT_COMMAND_LEN, MAVLINK_MSG_ID_FAULT_COMMAND_CRC);
#endif
}

#if MAVLINK_MSG_ID_FAULT_COMMAND_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_fault_command_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  const float *motor_ratio, const float *motor_time, const float *sensor_ratio, const float *sensor_time, const uint8_t *instruct)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;

    _mav_put_float_array(buf, 0, motor_ratio, 6);
    _mav_put_float_array(buf, 24, motor_time, 6);
    _mav_put_float_array(buf, 48, sensor_ratio, 10);
    _mav_put_float_array(buf, 88, sensor_time, 10);
    _mav_put_uint8_t_array(buf, 128, instruct, 4);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FAULT_COMMAND, buf, MAVLINK_MSG_ID_FAULT_COMMAND_MIN_LEN, MAVLINK_MSG_ID_FAULT_COMMAND_LEN, MAVLINK_MSG_ID_FAULT_COMMAND_CRC);
#else
    mavlink_fault_command_t *packet = (mavlink_fault_command_t *)msgbuf;

    mav_array_memcpy(packet->motor_ratio, motor_ratio, sizeof(float)*6);
    mav_array_memcpy(packet->motor_time, motor_time, sizeof(float)*6);
    mav_array_memcpy(packet->sensor_ratio, sensor_ratio, sizeof(float)*10);
    mav_array_memcpy(packet->sensor_time, sensor_time, sizeof(float)*10);
    mav_array_memcpy(packet->instruct, instruct, sizeof(uint8_t)*4);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FAULT_COMMAND, (const char *)packet, MAVLINK_MSG_ID_FAULT_COMMAND_MIN_LEN, MAVLINK_MSG_ID_FAULT_COMMAND_LEN, MAVLINK_MSG_ID_FAULT_COMMAND_CRC);
#endif
}
#endif

#endif

// MESSAGE FAULT_COMMAND UNPACKING


/**
 * @brief Get field motor_ratio from fault_command message
 *
 * @return  motor fault ratio
 */
static inline uint16_t mavlink_msg_fault_command_get_motor_ratio(const mavlink_message_t* msg, float *motor_ratio)
{
    return _MAV_RETURN_float_array(msg, motor_ratio, 6,  0);
}

/**
 * @brief Get field motor_time from fault_command message
 *
 * @return  motor fault time
 */
static inline uint16_t mavlink_msg_fault_command_get_motor_time(const mavlink_message_t* msg, float *motor_time)
{
    return _MAV_RETURN_float_array(msg, motor_time, 6,  24);
}

/**
 * @brief Get field sensor_ratio from fault_command message
 *
 * @return  sensor fault ratio
 */
static inline uint16_t mavlink_msg_fault_command_get_sensor_ratio(const mavlink_message_t* msg, float *sensor_ratio)
{
    return _MAV_RETURN_float_array(msg, sensor_ratio, 10,  48);
}

/**
 * @brief Get field sensor_time from fault_command message
 *
 * @return  sensor fault time
 */
static inline uint16_t mavlink_msg_fault_command_get_sensor_time(const mavlink_message_t* msg, float *sensor_time)
{
    return _MAV_RETURN_float_array(msg, sensor_time, 10,  88);
}

/**
 * @brief Get field instruct from fault_command message
 *
 * @return  unused
 */
static inline uint16_t mavlink_msg_fault_command_get_instruct(const mavlink_message_t* msg, uint8_t *instruct)
{
    return _MAV_RETURN_uint8_t_array(msg, instruct, 4,  128);
}

/**
 * @brief Decode a fault_command message into a struct
 *
 * @param msg The message to decode
 * @param fault_command C-struct to decode the message contents into
 */
static inline void mavlink_msg_fault_command_decode(const mavlink_message_t* msg, mavlink_fault_command_t* fault_command)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_fault_command_get_motor_ratio(msg, fault_command->motor_ratio);
    mavlink_msg_fault_command_get_motor_time(msg, fault_command->motor_time);
    mavlink_msg_fault_command_get_sensor_ratio(msg, fault_command->sensor_ratio);
    mavlink_msg_fault_command_get_sensor_time(msg, fault_command->sensor_time);
    mavlink_msg_fault_command_get_instruct(msg, fault_command->instruct);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_FAULT_COMMAND_LEN? msg->len : MAVLINK_MSG_ID_FAULT_COMMAND_LEN;
        memset(fault_command, 0, MAVLINK_MSG_ID_FAULT_COMMAND_LEN);
    memcpy(fault_command, _MAV_PAYLOAD(msg), len);
#endif
}
