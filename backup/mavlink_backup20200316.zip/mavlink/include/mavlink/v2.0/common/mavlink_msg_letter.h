#pragma once
// MESSAGE LETTER PACKING

#define MAVLINK_MSG_ID_LETTER 197

MAVPACKED(
typedef struct __mavlink_letter_t {
 float ft[4]; /*<  float*/
 uint16_t ux[4]; /*<  uint16*/
 uint8_t uo[4]; /*<  uint8*/
}) mavlink_letter_t;

#define MAVLINK_MSG_ID_LETTER_LEN 28
#define MAVLINK_MSG_ID_LETTER_MIN_LEN 28
#define MAVLINK_MSG_ID_197_LEN 28
#define MAVLINK_MSG_ID_197_MIN_LEN 28

#define MAVLINK_MSG_ID_LETTER_CRC 115
#define MAVLINK_MSG_ID_197_CRC 115

#define MAVLINK_MSG_LETTER_FIELD_FT_LEN 4
#define MAVLINK_MSG_LETTER_FIELD_UX_LEN 4
#define MAVLINK_MSG_LETTER_FIELD_UO_LEN 4

#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_LETTER { \
    197, \
    "LETTER", \
    3, \
    {  { "uo", NULL, MAVLINK_TYPE_UINT8_T, 4, 24, offsetof(mavlink_letter_t, uo) }, \
         { "ux", NULL, MAVLINK_TYPE_UINT16_T, 4, 16, offsetof(mavlink_letter_t, ux) }, \
         { "ft", NULL, MAVLINK_TYPE_FLOAT, 4, 0, offsetof(mavlink_letter_t, ft) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_LETTER { \
    "LETTER", \
    3, \
    {  { "uo", NULL, MAVLINK_TYPE_UINT8_T, 4, 24, offsetof(mavlink_letter_t, uo) }, \
         { "ux", NULL, MAVLINK_TYPE_UINT16_T, 4, 16, offsetof(mavlink_letter_t, ux) }, \
         { "ft", NULL, MAVLINK_TYPE_FLOAT, 4, 0, offsetof(mavlink_letter_t, ft) }, \
         } \
}
#endif

/**
 * @brief Pack a letter message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param uo  uint8
 * @param ux  uint16
 * @param ft  float
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_letter_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               const uint8_t *uo, const uint16_t *ux, const float *ft)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_LETTER_LEN];

    _mav_put_float_array(buf, 0, ft, 4);
    _mav_put_uint16_t_array(buf, 16, ux, 4);
    _mav_put_uint8_t_array(buf, 24, uo, 4);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_LETTER_LEN);
#else
    mavlink_letter_t packet;

    mav_array_memcpy(packet.ft, ft, sizeof(float)*4);
    mav_array_memcpy(packet.ux, ux, sizeof(uint16_t)*4);
    mav_array_memcpy(packet.uo, uo, sizeof(uint8_t)*4);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_LETTER_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_LETTER;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_LETTER_MIN_LEN, MAVLINK_MSG_ID_LETTER_LEN, MAVLINK_MSG_ID_LETTER_CRC);
}

/**
 * @brief Pack a letter message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param uo  uint8
 * @param ux  uint16
 * @param ft  float
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_letter_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   const uint8_t *uo,const uint16_t *ux,const float *ft)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_LETTER_LEN];

    _mav_put_float_array(buf, 0, ft, 4);
    _mav_put_uint16_t_array(buf, 16, ux, 4);
    _mav_put_uint8_t_array(buf, 24, uo, 4);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_LETTER_LEN);
#else
    mavlink_letter_t packet;

    mav_array_memcpy(packet.ft, ft, sizeof(float)*4);
    mav_array_memcpy(packet.ux, ux, sizeof(uint16_t)*4);
    mav_array_memcpy(packet.uo, uo, sizeof(uint8_t)*4);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_LETTER_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_LETTER;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_LETTER_MIN_LEN, MAVLINK_MSG_ID_LETTER_LEN, MAVLINK_MSG_ID_LETTER_CRC);
}

/**
 * @brief Encode a letter struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param letter C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_letter_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_letter_t* letter)
{
    return mavlink_msg_letter_pack(system_id, component_id, msg, letter->uo, letter->ux, letter->ft);
}

/**
 * @brief Encode a letter struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param letter C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_letter_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_letter_t* letter)
{
    return mavlink_msg_letter_pack_chan(system_id, component_id, chan, msg, letter->uo, letter->ux, letter->ft);
}

/**
 * @brief Send a letter message
 * @param chan MAVLink channel to send the message
 *
 * @param uo  uint8
 * @param ux  uint16
 * @param ft  float
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_letter_send(mavlink_channel_t chan, const uint8_t *uo, const uint16_t *ux, const float *ft)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_LETTER_LEN];

    _mav_put_float_array(buf, 0, ft, 4);
    _mav_put_uint16_t_array(buf, 16, ux, 4);
    _mav_put_uint8_t_array(buf, 24, uo, 4);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_LETTER, buf, MAVLINK_MSG_ID_LETTER_MIN_LEN, MAVLINK_MSG_ID_LETTER_LEN, MAVLINK_MSG_ID_LETTER_CRC);
#else
    mavlink_letter_t packet;

    mav_array_memcpy(packet.ft, ft, sizeof(float)*4);
    mav_array_memcpy(packet.ux, ux, sizeof(uint16_t)*4);
    mav_array_memcpy(packet.uo, uo, sizeof(uint8_t)*4);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_LETTER, (const char *)&packet, MAVLINK_MSG_ID_LETTER_MIN_LEN, MAVLINK_MSG_ID_LETTER_LEN, MAVLINK_MSG_ID_LETTER_CRC);
#endif
}

/**
 * @brief Send a letter message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_letter_send_struct(mavlink_channel_t chan, const mavlink_letter_t* letter)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_letter_send(chan, letter->uo, letter->ux, letter->ft);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_LETTER, (const char *)letter, MAVLINK_MSG_ID_LETTER_MIN_LEN, MAVLINK_MSG_ID_LETTER_LEN, MAVLINK_MSG_ID_LETTER_CRC);
#endif
}

#if MAVLINK_MSG_ID_LETTER_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_letter_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  const uint8_t *uo, const uint16_t *ux, const float *ft)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;

    _mav_put_float_array(buf, 0, ft, 4);
    _mav_put_uint16_t_array(buf, 16, ux, 4);
    _mav_put_uint8_t_array(buf, 24, uo, 4);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_LETTER, buf, MAVLINK_MSG_ID_LETTER_MIN_LEN, MAVLINK_MSG_ID_LETTER_LEN, MAVLINK_MSG_ID_LETTER_CRC);
#else
    mavlink_letter_t *packet = (mavlink_letter_t *)msgbuf;

    mav_array_memcpy(packet->ft, ft, sizeof(float)*4);
    mav_array_memcpy(packet->ux, ux, sizeof(uint16_t)*4);
    mav_array_memcpy(packet->uo, uo, sizeof(uint8_t)*4);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_LETTER, (const char *)packet, MAVLINK_MSG_ID_LETTER_MIN_LEN, MAVLINK_MSG_ID_LETTER_LEN, MAVLINK_MSG_ID_LETTER_CRC);
#endif
}
#endif

#endif

// MESSAGE LETTER UNPACKING


/**
 * @brief Get field uo from letter message
 *
 * @return  uint8
 */
static inline uint16_t mavlink_msg_letter_get_uo(const mavlink_message_t* msg, uint8_t *uo)
{
    return _MAV_RETURN_uint8_t_array(msg, uo, 4,  24);
}

/**
 * @brief Get field ux from letter message
 *
 * @return  uint16
 */
static inline uint16_t mavlink_msg_letter_get_ux(const mavlink_message_t* msg, uint16_t *ux)
{
    return _MAV_RETURN_uint16_t_array(msg, ux, 4,  16);
}

/**
 * @brief Get field ft from letter message
 *
 * @return  float
 */
static inline uint16_t mavlink_msg_letter_get_ft(const mavlink_message_t* msg, float *ft)
{
    return _MAV_RETURN_float_array(msg, ft, 4,  0);
}

/**
 * @brief Decode a letter message into a struct
 *
 * @param msg The message to decode
 * @param letter C-struct to decode the message contents into
 */
static inline void mavlink_msg_letter_decode(const mavlink_message_t* msg, mavlink_letter_t* letter)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_letter_get_ft(msg, letter->ft);
    mavlink_msg_letter_get_ux(msg, letter->ux);
    mavlink_msg_letter_get_uo(msg, letter->uo);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_LETTER_LEN? msg->len : MAVLINK_MSG_ID_LETTER_LEN;
        memset(letter, 0, MAVLINK_MSG_ID_LETTER_LEN);
    memcpy(letter, _MAV_PAYLOAD(msg), len);
#endif
}
