#pragma once
// MESSAGE FOLLOW_ME PACKING

#define MAVLINK_MSG_ID_FOLLOW_ME 190

MAVPACKED(
typedef struct __mavlink_follow_me_t {
 uint64_t timestamp; /*< [ms] Timestamp (time since system boot).*/
 uint64_t utc_time; /*< [ms] utc time.*/
 int32_t lat; /*< [degE7] Latitude (WGS84)*/
 int32_t lon; /*< [degE7] Longitude (WGS84)*/
 float alt; /*< [m] Altitude (MSL)*/
 float vel[3]; /*< [m/s] quad vel*/
 uint8_t type; /*< [m/s] formation type*/
 uint8_t info[3]; /*< [m/s] target velocity (0,0,0) for unknown*/
}) mavlink_follow_me_t;

#define MAVLINK_MSG_ID_FOLLOW_ME_LEN 44
#define MAVLINK_MSG_ID_FOLLOW_ME_MIN_LEN 44
#define MAVLINK_MSG_ID_190_LEN 44
#define MAVLINK_MSG_ID_190_MIN_LEN 44

#define MAVLINK_MSG_ID_FOLLOW_ME_CRC 36
#define MAVLINK_MSG_ID_190_CRC 36

#define MAVLINK_MSG_FOLLOW_ME_FIELD_VEL_LEN 3
#define MAVLINK_MSG_FOLLOW_ME_FIELD_INFO_LEN 3

#if MAVLINK_COMMAND_24BIT
#define MAVLINK_MESSAGE_INFO_FOLLOW_ME { \
    190, \
    "FOLLOW_ME", \
    8, \
    {  { "timestamp", NULL, MAVLINK_TYPE_UINT64_T, 0, 0, offsetof(mavlink_follow_me_t, timestamp) }, \
         { "utc_time", NULL, MAVLINK_TYPE_UINT64_T, 0, 8, offsetof(mavlink_follow_me_t, utc_time) }, \
         { "lat", NULL, MAVLINK_TYPE_INT32_T, 0, 16, offsetof(mavlink_follow_me_t, lat) }, \
         { "lon", NULL, MAVLINK_TYPE_INT32_T, 0, 20, offsetof(mavlink_follow_me_t, lon) }, \
         { "alt", NULL, MAVLINK_TYPE_FLOAT, 0, 24, offsetof(mavlink_follow_me_t, alt) }, \
         { "vel", NULL, MAVLINK_TYPE_FLOAT, 3, 28, offsetof(mavlink_follow_me_t, vel) }, \
         { "type", NULL, MAVLINK_TYPE_UINT8_T, 0, 40, offsetof(mavlink_follow_me_t, type) }, \
         { "info", NULL, MAVLINK_TYPE_UINT8_T, 3, 41, offsetof(mavlink_follow_me_t, info) }, \
         } \
}
#else
#define MAVLINK_MESSAGE_INFO_FOLLOW_ME { \
    "FOLLOW_ME", \
    8, \
    {  { "timestamp", NULL, MAVLINK_TYPE_UINT64_T, 0, 0, offsetof(mavlink_follow_me_t, timestamp) }, \
         { "utc_time", NULL, MAVLINK_TYPE_UINT64_T, 0, 8, offsetof(mavlink_follow_me_t, utc_time) }, \
         { "lat", NULL, MAVLINK_TYPE_INT32_T, 0, 16, offsetof(mavlink_follow_me_t, lat) }, \
         { "lon", NULL, MAVLINK_TYPE_INT32_T, 0, 20, offsetof(mavlink_follow_me_t, lon) }, \
         { "alt", NULL, MAVLINK_TYPE_FLOAT, 0, 24, offsetof(mavlink_follow_me_t, alt) }, \
         { "vel", NULL, MAVLINK_TYPE_FLOAT, 3, 28, offsetof(mavlink_follow_me_t, vel) }, \
         { "type", NULL, MAVLINK_TYPE_UINT8_T, 0, 40, offsetof(mavlink_follow_me_t, type) }, \
         { "info", NULL, MAVLINK_TYPE_UINT8_T, 3, 41, offsetof(mavlink_follow_me_t, info) }, \
         } \
}
#endif

/**
 * @brief Pack a follow_me message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param timestamp [ms] Timestamp (time since system boot).
 * @param utc_time [ms] utc time.
 * @param lat [degE7] Latitude (WGS84)
 * @param lon [degE7] Longitude (WGS84)
 * @param alt [m] Altitude (MSL)
 * @param vel [m/s] quad vel
 * @param type [m/s] formation type
 * @param info [m/s] target velocity (0,0,0) for unknown
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_follow_me_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg,
                               uint64_t timestamp, uint64_t utc_time, int32_t lat, int32_t lon, float alt, const float *vel, uint8_t type, const uint8_t *info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_FOLLOW_ME_LEN];
    _mav_put_uint64_t(buf, 0, timestamp);
    _mav_put_uint64_t(buf, 8, utc_time);
    _mav_put_int32_t(buf, 16, lat);
    _mav_put_int32_t(buf, 20, lon);
    _mav_put_float(buf, 24, alt);
    _mav_put_uint8_t(buf, 40, type);
    _mav_put_float_array(buf, 28, vel, 3);
    _mav_put_uint8_t_array(buf, 41, info, 3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_FOLLOW_ME_LEN);
#else
    mavlink_follow_me_t packet;
    packet.timestamp = timestamp;
    packet.utc_time = utc_time;
    packet.lat = lat;
    packet.lon = lon;
    packet.alt = alt;
    packet.type = type;
    mav_array_memcpy(packet.vel, vel, sizeof(float)*3);
    mav_array_memcpy(packet.info, info, sizeof(uint8_t)*3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_FOLLOW_ME_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_FOLLOW_ME;
    return mavlink_finalize_message(msg, system_id, component_id, MAVLINK_MSG_ID_FOLLOW_ME_MIN_LEN, MAVLINK_MSG_ID_FOLLOW_ME_LEN, MAVLINK_MSG_ID_FOLLOW_ME_CRC);
}

/**
 * @brief Pack a follow_me message on a channel
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param timestamp [ms] Timestamp (time since system boot).
 * @param utc_time [ms] utc time.
 * @param lat [degE7] Latitude (WGS84)
 * @param lon [degE7] Longitude (WGS84)
 * @param alt [m] Altitude (MSL)
 * @param vel [m/s] quad vel
 * @param type [m/s] formation type
 * @param info [m/s] target velocity (0,0,0) for unknown
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_follow_me_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan,
                               mavlink_message_t* msg,
                                   uint64_t timestamp,uint64_t utc_time,int32_t lat,int32_t lon,float alt,const float *vel,uint8_t type,const uint8_t *info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_FOLLOW_ME_LEN];
    _mav_put_uint64_t(buf, 0, timestamp);
    _mav_put_uint64_t(buf, 8, utc_time);
    _mav_put_int32_t(buf, 16, lat);
    _mav_put_int32_t(buf, 20, lon);
    _mav_put_float(buf, 24, alt);
    _mav_put_uint8_t(buf, 40, type);
    _mav_put_float_array(buf, 28, vel, 3);
    _mav_put_uint8_t_array(buf, 41, info, 3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), buf, MAVLINK_MSG_ID_FOLLOW_ME_LEN);
#else
    mavlink_follow_me_t packet;
    packet.timestamp = timestamp;
    packet.utc_time = utc_time;
    packet.lat = lat;
    packet.lon = lon;
    packet.alt = alt;
    packet.type = type;
    mav_array_memcpy(packet.vel, vel, sizeof(float)*3);
    mav_array_memcpy(packet.info, info, sizeof(uint8_t)*3);
        memcpy(_MAV_PAYLOAD_NON_CONST(msg), &packet, MAVLINK_MSG_ID_FOLLOW_ME_LEN);
#endif

    msg->msgid = MAVLINK_MSG_ID_FOLLOW_ME;
    return mavlink_finalize_message_chan(msg, system_id, component_id, chan, MAVLINK_MSG_ID_FOLLOW_ME_MIN_LEN, MAVLINK_MSG_ID_FOLLOW_ME_LEN, MAVLINK_MSG_ID_FOLLOW_ME_CRC);
}

/**
 * @brief Encode a follow_me struct
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param follow_me C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_follow_me_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_follow_me_t* follow_me)
{
    return mavlink_msg_follow_me_pack(system_id, component_id, msg, follow_me->timestamp, follow_me->utc_time, follow_me->lat, follow_me->lon, follow_me->alt, follow_me->vel, follow_me->type, follow_me->info);
}

/**
 * @brief Encode a follow_me struct on a channel
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message will be sent over
 * @param msg The MAVLink message to compress the data into
 * @param follow_me C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_follow_me_encode_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, const mavlink_follow_me_t* follow_me)
{
    return mavlink_msg_follow_me_pack_chan(system_id, component_id, chan, msg, follow_me->timestamp, follow_me->utc_time, follow_me->lat, follow_me->lon, follow_me->alt, follow_me->vel, follow_me->type, follow_me->info);
}

/**
 * @brief Send a follow_me message
 * @param chan MAVLink channel to send the message
 *
 * @param timestamp [ms] Timestamp (time since system boot).
 * @param utc_time [ms] utc time.
 * @param lat [degE7] Latitude (WGS84)
 * @param lon [degE7] Longitude (WGS84)
 * @param alt [m] Altitude (MSL)
 * @param vel [m/s] quad vel
 * @param type [m/s] formation type
 * @param info [m/s] target velocity (0,0,0) for unknown
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_follow_me_send(mavlink_channel_t chan, uint64_t timestamp, uint64_t utc_time, int32_t lat, int32_t lon, float alt, const float *vel, uint8_t type, const uint8_t *info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char buf[MAVLINK_MSG_ID_FOLLOW_ME_LEN];
    _mav_put_uint64_t(buf, 0, timestamp);
    _mav_put_uint64_t(buf, 8, utc_time);
    _mav_put_int32_t(buf, 16, lat);
    _mav_put_int32_t(buf, 20, lon);
    _mav_put_float(buf, 24, alt);
    _mav_put_uint8_t(buf, 40, type);
    _mav_put_float_array(buf, 28, vel, 3);
    _mav_put_uint8_t_array(buf, 41, info, 3);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FOLLOW_ME, buf, MAVLINK_MSG_ID_FOLLOW_ME_MIN_LEN, MAVLINK_MSG_ID_FOLLOW_ME_LEN, MAVLINK_MSG_ID_FOLLOW_ME_CRC);
#else
    mavlink_follow_me_t packet;
    packet.timestamp = timestamp;
    packet.utc_time = utc_time;
    packet.lat = lat;
    packet.lon = lon;
    packet.alt = alt;
    packet.type = type;
    mav_array_memcpy(packet.vel, vel, sizeof(float)*3);
    mav_array_memcpy(packet.info, info, sizeof(uint8_t)*3);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FOLLOW_ME, (const char *)&packet, MAVLINK_MSG_ID_FOLLOW_ME_MIN_LEN, MAVLINK_MSG_ID_FOLLOW_ME_LEN, MAVLINK_MSG_ID_FOLLOW_ME_CRC);
#endif
}

/**
 * @brief Send a follow_me message
 * @param chan MAVLink channel to send the message
 * @param struct The MAVLink struct to serialize
 */
static inline void mavlink_msg_follow_me_send_struct(mavlink_channel_t chan, const mavlink_follow_me_t* follow_me)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    mavlink_msg_follow_me_send(chan, follow_me->timestamp, follow_me->utc_time, follow_me->lat, follow_me->lon, follow_me->alt, follow_me->vel, follow_me->type, follow_me->info);
#else
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FOLLOW_ME, (const char *)follow_me, MAVLINK_MSG_ID_FOLLOW_ME_MIN_LEN, MAVLINK_MSG_ID_FOLLOW_ME_LEN, MAVLINK_MSG_ID_FOLLOW_ME_CRC);
#endif
}

#if MAVLINK_MSG_ID_FOLLOW_ME_LEN <= MAVLINK_MAX_PAYLOAD_LEN
/*
  This varient of _send() can be used to save stack space by re-using
  memory from the receive buffer.  The caller provides a
  mavlink_message_t which is the size of a full mavlink message. This
  is usually the receive buffer for the channel, and allows a reply to an
  incoming message with minimum stack space usage.
 */
static inline void mavlink_msg_follow_me_send_buf(mavlink_message_t *msgbuf, mavlink_channel_t chan,  uint64_t timestamp, uint64_t utc_time, int32_t lat, int32_t lon, float alt, const float *vel, uint8_t type, const uint8_t *info)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    char *buf = (char *)msgbuf;
    _mav_put_uint64_t(buf, 0, timestamp);
    _mav_put_uint64_t(buf, 8, utc_time);
    _mav_put_int32_t(buf, 16, lat);
    _mav_put_int32_t(buf, 20, lon);
    _mav_put_float(buf, 24, alt);
    _mav_put_uint8_t(buf, 40, type);
    _mav_put_float_array(buf, 28, vel, 3);
    _mav_put_uint8_t_array(buf, 41, info, 3);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FOLLOW_ME, buf, MAVLINK_MSG_ID_FOLLOW_ME_MIN_LEN, MAVLINK_MSG_ID_FOLLOW_ME_LEN, MAVLINK_MSG_ID_FOLLOW_ME_CRC);
#else
    mavlink_follow_me_t *packet = (mavlink_follow_me_t *)msgbuf;
    packet->timestamp = timestamp;
    packet->utc_time = utc_time;
    packet->lat = lat;
    packet->lon = lon;
    packet->alt = alt;
    packet->type = type;
    mav_array_memcpy(packet->vel, vel, sizeof(float)*3);
    mav_array_memcpy(packet->info, info, sizeof(uint8_t)*3);
    _mav_finalize_message_chan_send(chan, MAVLINK_MSG_ID_FOLLOW_ME, (const char *)packet, MAVLINK_MSG_ID_FOLLOW_ME_MIN_LEN, MAVLINK_MSG_ID_FOLLOW_ME_LEN, MAVLINK_MSG_ID_FOLLOW_ME_CRC);
#endif
}
#endif

#endif

// MESSAGE FOLLOW_ME UNPACKING


/**
 * @brief Get field timestamp from follow_me message
 *
 * @return [ms] Timestamp (time since system boot).
 */
static inline uint64_t mavlink_msg_follow_me_get_timestamp(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint64_t(msg,  0);
}

/**
 * @brief Get field utc_time from follow_me message
 *
 * @return [ms] utc time.
 */
static inline uint64_t mavlink_msg_follow_me_get_utc_time(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint64_t(msg,  8);
}

/**
 * @brief Get field lat from follow_me message
 *
 * @return [degE7] Latitude (WGS84)
 */
static inline int32_t mavlink_msg_follow_me_get_lat(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  16);
}

/**
 * @brief Get field lon from follow_me message
 *
 * @return [degE7] Longitude (WGS84)
 */
static inline int32_t mavlink_msg_follow_me_get_lon(const mavlink_message_t* msg)
{
    return _MAV_RETURN_int32_t(msg,  20);
}

/**
 * @brief Get field alt from follow_me message
 *
 * @return [m] Altitude (MSL)
 */
static inline float mavlink_msg_follow_me_get_alt(const mavlink_message_t* msg)
{
    return _MAV_RETURN_float(msg,  24);
}

/**
 * @brief Get field vel from follow_me message
 *
 * @return [m/s] quad vel
 */
static inline uint16_t mavlink_msg_follow_me_get_vel(const mavlink_message_t* msg, float *vel)
{
    return _MAV_RETURN_float_array(msg, vel, 3,  28);
}

/**
 * @brief Get field type from follow_me message
 *
 * @return [m/s] formation type
 */
static inline uint8_t mavlink_msg_follow_me_get_type(const mavlink_message_t* msg)
{
    return _MAV_RETURN_uint8_t(msg,  40);
}

/**
 * @brief Get field info from follow_me message
 *
 * @return [m/s] target velocity (0,0,0) for unknown
 */
static inline uint16_t mavlink_msg_follow_me_get_info(const mavlink_message_t* msg, uint8_t *info)
{
    return _MAV_RETURN_uint8_t_array(msg, info, 3,  41);
}

/**
 * @brief Decode a follow_me message into a struct
 *
 * @param msg The message to decode
 * @param follow_me C-struct to decode the message contents into
 */
static inline void mavlink_msg_follow_me_decode(const mavlink_message_t* msg, mavlink_follow_me_t* follow_me)
{
#if MAVLINK_NEED_BYTE_SWAP || !MAVLINK_ALIGNED_FIELDS
    follow_me->timestamp = mavlink_msg_follow_me_get_timestamp(msg);
    follow_me->utc_time = mavlink_msg_follow_me_get_utc_time(msg);
    follow_me->lat = mavlink_msg_follow_me_get_lat(msg);
    follow_me->lon = mavlink_msg_follow_me_get_lon(msg);
    follow_me->alt = mavlink_msg_follow_me_get_alt(msg);
    mavlink_msg_follow_me_get_vel(msg, follow_me->vel);
    follow_me->type = mavlink_msg_follow_me_get_type(msg);
    mavlink_msg_follow_me_get_info(msg, follow_me->info);
#else
        uint8_t len = msg->len < MAVLINK_MSG_ID_FOLLOW_ME_LEN? msg->len : MAVLINK_MSG_ID_FOLLOW_ME_LEN;
        memset(follow_me, 0, MAVLINK_MSG_ID_FOLLOW_ME_LEN);
    memcpy(follow_me, _MAV_PAYLOAD(msg), len);
#endif
}
