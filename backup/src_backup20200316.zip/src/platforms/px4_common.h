#pragma once

#ifdef __PX4_QURT
#include <types.h>
size_t strnlen(const char *s, size_t maxlen);

#endif
