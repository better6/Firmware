/****************************************************************************
 *
 *   Copyright (c) 2016 PX4 Development Team. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name PX4 nor the names of its contributors may be
 *    used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * AS IS AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 ****************************************************************************/

/**
 * @file follow_target_params.c
 *
 * Parameters for follow target mode
 *
 * @author Jimmy Johnson <catch22@fastmail.net>
 */

/*
 * Follow target parameters
 */

/**
 * Minimum follow target altitude 
 *
 * The minimum height in meters relative to home for following a target
 *
 * @unit meters
 * @min 5.0
 * @group Follow target
 */
PARAM_DEFINE_FLOAT(NAV_MIN_FT_HT, 5.0f);  //跟随目标的最低高度，单位米

/**
 * Distance to follow target from 
 *
 * The distance in meters to follow the target at
 *
 * @unit meters
 * @min 3.0
 * @group Follow target
 */
PARAM_DEFINE_FLOAT(NAV_FT_DST, 6.0f); //跟随目标的距离，单位米

/**
 * Side to follow target from
 *
 * The side to follow the target from (front right = 0, behind = 1, front = 2, front left = 3)
 *
 * @unit n/a
 * @min 0
 * @max 5
 * @group Follow target
 */
PARAM_DEFINE_INT32(NAV_FT_FS, 1); //从哪个侧面跟随目标 右面、后面、前面、前左，可以测试下效果

/**
 * Dynamic filtering algorithm responsiveness to target movement
 * lower numbers increase the responsiveness to changing long lat
 * but also ignore less noise
 *
 * @unit n/a
 * @min 0.0
 * @max 1.0
 * @decimal 2
 * @group Follow target
 */
PARAM_DEFINE_FLOAT(FT_POS_FLITER, 0.2f); //滤波算法 上次位置指令权重+本次位置指令×（1-权重），对主机发给从机的位置指令进行滤波，避免变化剧烈，因为我们这主机更新频率慢 所以滤波可以不做


/**
 * Dynamic filtering algorithm responsiveness to target movement
 * lower numbers increase the responsiveness to changing long lat
 * but also ignore less noise
 *
 * @unit n/a
 * @min 0.0
 * @max 10.0
 * @decimal 2
 * @group Follow target
 */
PARAM_DEFINE_FLOAT(FT_POS_FF, 1.5f); //滤波算法 上次位置指令权重+本次位置指令×（1-权重），对主机发给从机的位置指令进行滤波，避免变化剧烈，因为我们这主机更新频率慢 所以滤波可以不做


/**
 * enter speed follow distance
 *
 *
 * @unit n/a
 * @min 0
 * @max 5
 * @group Follow target
 */
PARAM_DEFINE_INT32(FT_ENTER_SPD, 5); //从哪个侧面跟随目标 右面、后面、前面、前左，可以测试下效果

/**
 * Dynamic filtering algorithm responsiveness to target movement
 * lower numbers increase the responsiveness to changing long lat
 * but also ignore less noise
 *
 * @unit n/a
 * @min 0.0
 * @max 1.0
 * @decimal 2
 * @group Follow target
 */
PARAM_DEFINE_FLOAT(FT_VEL_FILTER, 0.2f); //滤波算法 上次位置指令权重+本次位置指令×（1-权重），对主机发给从机的位置指令进行滤波，避免变化剧烈，因为我们这主机更新频率慢 所以滤波可以不做

